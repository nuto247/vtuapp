<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .content {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <div class="content">
        <p><?php echo e($content); ?></p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\tochukwu\Desktop\projects\vtuapp\resources\views/pdf/my_pdf_view.blade.php ENDPATH**/ ?>