

<?php $__env->startSection('content'); ?>
<div class="container">
    <form>
        <div class="form-group">
            <label for="variation_id">Variation</label>
            <select class="form-control" id="variation_id" name="variation_id">
                <option value="">Select Variation</option>
                <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($variation->id); ?>"><?php echo e($variation->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="network">Network</label>
            <input type="text" class="form-control" id="network" name="network" readonly>
        </div>
        <div class="form-group">
            <label for="plan">Plan</label>
            <input type="text" class="form-control" id="plan" name="plan" readonly>
        </div>
        <div class="form-group">
            <label for="price">Price</label>
            <input type="text" class="form-control" id="price" name="price" readonly>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.getElementById('variation_id').addEventListener('change', function() {
        var variationId = this.value;
        if (variationId) {
            fetch(`/getDetails/${variationId}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('network').value = data.network ? data.network.name : '';
                    document.getElementById('plan').value = data.plan ? data.plan.name : '';
                    document.getElementById('price').value = data.price ? data.price.amount : '';
                })
                .catch(error => console.error('Error:', error));
        } else {
            document.getElementById('network').value = '';
            document.getElementById('plan').value = '';
            document.getElementById('price').value = '';
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tochukwu\Desktop\projects\vtuapp\resources\views/form.blade.php ENDPATH**/ ?>