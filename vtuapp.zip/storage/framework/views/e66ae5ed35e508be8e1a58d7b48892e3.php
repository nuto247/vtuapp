<?php if(session()->has('alert-message') && session()->get('alert-message.type') == 'danger'): ?>
<div class="alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h5><i class="icon fas fa-ban"></i>  <?php echo e(session()->get('alert-message.title')); ?></h5>
    <?php echo e(session()->get('alert-message.message')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('alert-message') && session()->get('alert-message.type') == 'info'): ?>
<div class="alert alert-info alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h5><i class="icon fas fa-info"></i> <?php echo e(session()->get('alert-message.title')); ?></h5>
    <?php echo e(session()->get('alert-message.message')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('alert-message') && session()->get('alert-message.type') == 'warning'): ?>
<div class="alert alert-warning alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h5><i class="icon fas fa-exclamation-triangle"></i><?php echo e(session()->get('alert-message.title')); ?></h5>
    <?php echo e(session()->get('alert-message.message')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('alert-message') && session()->get('alert-message.type') == 'success'): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h5><i class="icon fas fa-check"></i><?php echo e(session()->get('alert-message.title')); ?></h5>
    <?php echo e(session()->get('alert-message.message')); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\Users\tochukwu\Desktop\projects\vtuapp\resources\views/partials/alert-messages.blade.php ENDPATH**/ ?>