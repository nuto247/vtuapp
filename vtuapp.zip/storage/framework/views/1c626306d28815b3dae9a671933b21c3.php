<!DOCTYPE html>
<html>
<head>
    <title>Dependent Select Form</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <h2>Dependent Select Form</h2>
    <form action="#" method="post">
        <?php echo csrf_field(); ?>
        <div>
            <label for="category">Select Category:</label>
            <select name="category" id="category">
                <option value="">-- Select Category --</option>
                <?php $__currentLoopData = $dataprices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->network); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="subcategory">Select Subcategory:</label>
            <select name="subcategory" id="subcategory" multiple>
                <option value="">-- Select Subcategory --</option>
            </select>
        </div>

        <button type="submit">Submit</button>
    </form>

    <script>
        $(document).ready(function(){
            $('#category').on('change', function(){
                var category_id = $(this).val();
                $('#subcategory').empty();
                if(category_id){
                    $.ajax({
                        url: '<?php echo e(route("getSubcategories")); ?>',
                        type: 'GET',
                        data: {category_id: category_id},
                        dataType: 'json',
                        success: function(data){
                            $.each(data, function(key, value){
                                $('#subcategory').append('<option value="'+key+'">'+value+'</option>');
                            });
                        }
                    });
                } else {
                    $('#subcategory').append('<option value="">-- Select Subcategory --</option>');
                }
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\tochukwu\Desktop\projects\vtux11\resources\views/formshow.blade.php ENDPATH**/ ?>