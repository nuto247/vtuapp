<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Datasetting extends Controller
{
    //
}
